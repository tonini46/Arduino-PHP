#1)Files to be edited: 
	ajaxgrid.js 
	example.php
	edit.php
	grid.php

#2) The variable "url", declared in the top of "ajaxgrid.js" file, defines the server side file, which is called after the save button is pressed

#3) Make sure you include "prototype.js", "ajaxgrid.js" on the top if the HTML file

#4) "idName1", "idName2", "idName3", "idName4" on the top of "ajaxgrid.js" are the ids of the four elements of the grid

#5) I have used text file to read and store the text, but you can also use XML or Database to do the same.

#6) This is just a learing demo, for fully commertial/live code, feel free to contact me.

#7) The whole code is not totaly OOPS Oriented, in order to make it easier to understand. 