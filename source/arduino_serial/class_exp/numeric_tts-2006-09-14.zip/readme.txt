                            Numeric TTS v 1.0
                          http://www.SysTurn.com

//   This program is free software; you can redistribute it and/or modify
//   it under the terms of the ISLAMIC RULES and GNU Lesser General Public
//   License either version 2, or (at your option) any later version.
//
//   ISLAMIC RULES should be followed and respected if they differ
//   than terms of the GNU LESSER GENERAL PUBLIC LICENSE
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of the license with this software;
//   If not, please contact support @ S y s T u r n .com to receive a copy.



What is this ?
==============
This class converts numbers from text into wave format.
supports Male and Female voices, and can easily support
Languages other than english.


How does it work ?
===================
The idea of this class is concatenation audio samples that
spell the digits of a number. Then it generates the wave header
(the first 44 bytes of the file).


How to use this ?
=================
The class can be used in one of the following ways:
1- NumericTTS::write($input_number, $output_file)
   The write() function will spell and generate the wav
   file for the input number and store it in the output file.
   
2- NumericTTS::output($input_number)
   The output function will spell and generate the wav
   output for the input number which will be served
   as the current script output.
   
This class depends on pre-recorded wav files, so it can support
multiple voices and languages. Currently it have Male and Female
voices in English, and other four voices in Arabic.

The default voice is Female English. To change the voice you will
need to call the function setVoice($voice_name) before calling the
write() or output() functions.

Voices can be downloaded from:
http://systurn.com/numeric_tts/voices.zip


Looking For Examples ?
======================
Refer to the examples (files starts with "example.")
Online Example: http://systurn.com/numeric_tts/example.output.php