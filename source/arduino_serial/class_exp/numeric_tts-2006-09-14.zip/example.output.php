<?php
//
// +-----------------------------------+
// |        Numeric TTS v 1.0          |
// |      http://www.SysTurn.com       |
// +-----------------------------------+
//
//
//   This program is free software; you can redistribute it and/or modify
//   it under the terms of the ISLAMIC RULES and GNU Lesser General Public
//   License either version 2, or (at your option) any later version.
//
//   ISLAMIC RULES should be followed and respected if they differ
//   than terms of the GNU LESSER GENERAL PUBLIC LICENSE
//
//   This program is distributed in the hope that it will be useful,
//   but WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//   GNU General Public License for more details.
//
//   You should have received a copy of the license with this software;
//   If not, please contact support @ S y s T u r n .com to receive a copy.
//

  if(isset($_POST['number']))
  {
    require_once('class.numericTTS.php');

    $tts = new NumericTTS;

    $tts->setVoice($_POST['voice']);
    
    header('Content-Disposition: attachment; filename="output.wav"');
    
    $tts->output($_POST['number']);
  }
?>
<html>
<head>
    <title>Numeric TTS Example</title>
    <style type="text/css">
<!--
.Title {
    font-family: Geneva, Arial, Helvetica, sans-serif;
    font-size: 24px;
    text-decoration: none;
    color: #0099FF;
}
.Form {
    font-family: Geneva, Arial, Helvetica, sans-serif;
    font-size: 12px;
    color: #003399;
    text-decoration: none;
    font-weight: bold;
    text-align: right;
}
.finput {
    font-family: Geneva, Arial, Helvetica, sans-serif;
    color: #333333;
    text-decoration: none;
    font-size: 12px;
    width: 100%;
}
-->
    </style>
</head>
<body>
<form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST" name="exampleForm" style="margin:0px">
<table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td>&nbsp;</td>
    <td align="center"><span class="Title">Numeric TTS Example</span><br />
      <br />
        <table border="0" cellpadding="2" cellspacing="5">
      <tr>
        <td width="60" class="Form">Number:</td>
        <td class="Form" style="width:155px"><input name="number" type="text" class="finput"/></td>
        <td width="48" rowspan="2" class="Form"><input type="image" src="play.jpg" width="48" height="48" /></td>
      </tr>
      <tr>
        <td class="Form">Voice:</td>
        <td class="Form" style="width:155px"><select name="voice" class="finput">
            <option selected="selected" value="female">Female English</option>
            <option value="male">Male English</option>
            <option value="female_ar">Female Arabic</option>
            <option value="male_ar">Male Arabic</option>
            <option value="female_ar2">Female Arabic 2</option>
            <option value="male_ar2">Male Arabic 2</option>
          </select></td>
        </tr>
    </table></td>
    <td>&nbsp;</td>
  </tr>
</table>
</form>
</body>
</html>