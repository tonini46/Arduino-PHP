{header}
{links}
<?php 

// Example how variables are passed by the data variable

echo $testVar;?>
{footer}